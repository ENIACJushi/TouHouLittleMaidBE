export const recipe = {
  "type": "touhou_little_maid:altar_crafting",
  "output": {
    "type": "thlm:repair",
    "item": {
      "target": {
        "tag": "thlm:gohei"
      },
      "amount": 300
    }
  },
  "power": 0.10,
  "ingredients": [
    {
      "tag": "thlm:gohei"
    },
    {
      "item": "minecraft:paper"
    },
    {
      "item": "minecraft:paper"
    }
  ]
}