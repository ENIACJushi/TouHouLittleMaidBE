export const recipe = {
  "type": "touhou_little_maid:altar_crafting",
  "output": {
    "type": "minecraft:item",
    "nbt": {
      "Item": {
        "id": "touhou_little_maid:maid_backpack_big",
        "Count": 1
      }
    }
  },
  "power": 0.3,
  "ingredients": [
    {
      "item": "minecraft:gray_wool"
    },
    {
      "item": "minecraft:gray_wool"
    },
    {
      "item": "minecraft:gray_wool"
    },
    {
      "item": "minecraft:gray_wool"
    },
    {
      "tag": "forge:gems/diamond"
    },
    {
      "item": "minecraft:gray_wool"
    }
  ]
}