export const recipe = {
  "type": "touhou_little_maid:altar_crafting",
  "output": {
    "type": "minecraft:item",
    "nbt": {
      "Item": {
        "id": "touhou_little_maid:maid_backpack_small",
        "Count": 1
      }
    }
  },
  "power": 0.1,
  "ingredients": [
    {
      "item": "minecraft:red_wool"
    },
    {
      "item": "minecraft:red_wool"
    },
    {
      "item": "minecraft:red_wool"
    },
    {
      "item": "minecraft:red_wool"
    },
    {
      "tag": "forge:ingots/iron"
    },
    {
      "item": "minecraft:red_wool"
    }
  ]
}