export const recipe = {
  "type": "touhou_little_maid:altar_crafting",
  "output": {
    "type": "minecraft:item",
    "nbt": {
      "Item": {
        "id": "touhou_little_maid:item_magnet_bauble",
        "Count": 1
      }
    }
  },
  "power": 0.2,
  "ingredients": [
    {
      "tag": "forge:dusts/redstone"
    },
    {
      "tag": "forge:dusts/redstone"
    },
    {
      "tag": "forge:dusts/redstone"
    },
    {
      "tag": "forge:ingots/iron"
    },
    {
      "tag": "forge:ingots/iron"
    },
    {
      "tag": "forge:ingots/iron"
    }
  ]
}