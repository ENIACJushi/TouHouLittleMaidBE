export const recipe = {
  "type": "touhou_little_maid:altar_crafting",
  "output": {
    "type": "minecraft:item",
    "nbt": {
      "Item": {
        "id": "touhou_little_maid:mute_bauble",
        "Count": 1
      }
    }
  },
  "power": 0.2,
  "ingredients": [
    {
      "tag": "minecraft:wool"
    },
    {
      "tag": "minecraft:wool"
    },
    {
      "tag": "minecraft:wool"
    },
    {
      "item": "minecraft:clay_ball"
    },
    {
      "item": "minecraft:clay_ball"
    },
    {
      "item": "minecraft:clay_ball"
    }
  ]
}