export const recipe = {
  "type": "touhou_little_maid:altar_crafting",
  "output": {
    "type": "minecraft:item",
    "nbt": {
      "Item": {
        "id": "touhou_little_maid:maid_backpack_middle",
        "Count": 1
      }
    }
  },
  "power": 0.2,
  "ingredients": [
    {
      "item": "minecraft:pink_wool"
    },
    {
      "item": "minecraft:pink_wool"
    },
    {
      "item": "minecraft:pink_wool"
    },
    {
      "item": "minecraft:pink_wool"
    },
    {
      "tag": "forge:ingots/gold"
    },
    {
      "item": "minecraft:pink_wool"
    }
  ]
}