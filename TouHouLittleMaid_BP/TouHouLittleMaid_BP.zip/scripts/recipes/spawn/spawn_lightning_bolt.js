export const recipe = {
  "type": "touhou_little_maid:altar_crafting",
  "output": {
    "type": "minecraft:lightning_bolt"
  },
  "power": 0.2,
  "ingredients": [
    {
      "tag": "forge:gunpowder"
    },
    {
      "tag": "forge:gunpowder"
    },
    {
      "tag": "forge:gunpowder"
    },
    {
      "item": "minecraft:blaze_powder"
    },
    {
      "item": "minecraft:blaze_powder"
    },
    {
      "item": "minecraft:blaze_powder"
    }
  ]
}