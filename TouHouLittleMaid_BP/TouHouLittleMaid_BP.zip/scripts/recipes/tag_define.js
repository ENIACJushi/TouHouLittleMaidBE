export const tagDefines = {
    "forge:gunpowder": [
        {"item": "minecraft:gunpowder"}
    ],
    "forge:rods/wooden": [
        {"item": "minecraft:stick"}
    ],
    "thlm:gohei":[
        {"item": "touhou_little_maid:hakurei_gohei_pellet"},
        {"item": "touhou_little_maid:hakurei_gohei_orbs"},
        {"item": "touhou_little_maid:hakurei_gohei_ball"},
        {"item": "touhou_little_maid:hakurei_gohei_big_ball"}
    ]
}